
<?php $__env->startSection('body'); ?>
<?php $__currentLoopData = $problemtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="table-responsive">

    <p><h2>แก้ไข้ หัวข้อปัญหา</h2></p>
    <form action="/admin/Problemtype/update/<?php echo e($pbty->id); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        

            <div class="form-group">
                <label for="ProblemName">หัวข้อปัญหา <label style="color:red;"> * </label></label>
                <input type="text" class="form-control" name="ProblemName" id="ProblemName" value="<?php echo e($pbty->ProblemName); ?>">
            </div>

            <button type="submit" name="submit" class="btn btn-warning">แก้ไขข้อมูล</button>
            <button class="btn btn-secondary" type="reset">ยกเลิก</button>
        </form>

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/problemtype/edit.blade.php ENDPATH**/ ?>