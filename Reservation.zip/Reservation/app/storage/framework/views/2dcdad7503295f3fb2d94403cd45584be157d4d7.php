<?php $__env->startSection('body'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
<div class="table-responsive">
    
    <p><h2>เพื่มข้อมูล ห้องพัก </h2></p>
    <form action="<?php echo e(route('rooms.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        
        <div class="form-inline">
            <div class="form-group col-xs-12 col-sm-12 col-md-12 my-2">
                <strong class="col-sm-2" for="Dormitory_ID">ชื่อหอพัก <strong style="color:red;"> * </strong></strong>
                <div class = "col-sm-9">
                    <input type="hidden" value= "<?php echo e($dormitory[0]->id); ?>" class="form-control" name="Dormitory_ID" id="Dormitory_ID"/>
                    <input type="text" class="form-control" name="Dormitory_NAME" id="Dormitory_NAME" value="<?php echo e($dormitory[0]->Name_Thai); ?>"   readonly>
                </div>
            </div>

            <div class="form-group col-xs-12 col-sm-12 col-md-12 my-2">
                <strong class="col-sm-2" for="Roomtype_ID">ประเภทห้องพัก <strong style="color:red;"> * </strong></strong>
                <div class = "col-sm-9">
                    <input type="hidden" value= "<?php echo e($type); ?>" class="form-control" name="Roomtype_ID" id="Roomtype_ID" />
                    <input type="text" class="form-control" name="Roomtype_NAME" id="Roomtype_NAME"

                    <?php if( $type == 1  ): ?>
                        value="ห้องปรับอากาศ "
                    <?php else: ?>
                        value="ห้องพัดลม  "
                    <?php endif; ?>
                    readonly
                    >
                </div>
            </div>

            <div class="form-group col-xs-12 col-sm-12 col-md-12 my-2">
                <strong class="col-sm-2"  for="RoomCode_ID">เลขห้อง<strong style="color:red;"> * </strong></strong>
                <input type="text" class="form-control col-sm-3" name="RoomCode_ID" id="RoomCode_ID" placeholder="เลขห้อง ... ">

                <strong class="col-sm-1" for="Floor">ชั้น <strong style="color:red;"> * </strong></strong>
                <input type="text" class="form-control col-sm-3" name="Floor" id="Floor" placeholder="ชั้น ...">

                &nbsp; &nbsp;
                <button type="submit" name="submit" class="btn btn-success" href="<?php echo e(route('rooms.create',$dormitory[0]->id.":".$type)); ?>">เพื่มข้อมูล</button>
                <button class="btn btn-secondary" type="reset">ยกเลิก</button>
            </div>
        </div>
    </form>
</div>
<?php if($room->count()>0): ?>
    <div class="col-md-12">
    <div class="card">
        <div class="table-responsive my-3">
            <table class="table" border="0">
                <thead class="thead-dark">
                    <th><center>#ลำดับ</center></th>
                    <th><center>เลขหอพัก</center></th>
                    <th><center>ชั้น</center></th>
                    <th><center>จำนวนคน</center></th>
                    <th><center>สถานะ</center></th>
                    <th><center>ประเภทห้องพัก </center></th>
                    <th><center>ชื่อหอพัก </center></th>
                    <th><center>การดำเนินการ</center></th>

                    
                </thead>
                <?php   $i=1;?>
                <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($rm->RoomCode_ID); ?></td>
                    <td><?php echo e($rm->Floor); ?></td>
                    <td><?php echo e($rm->NumberPeople); ?> คน/ห้อง</td>
                    <td>
                        <?php if( $rm->NumberPeople == $rm->AtNumberPreple ): ?>
                        <p style="color: #ff1a1a"> ห้องเต็ม</p>
                        <?php else: ?>
                        <p style="color: #00cc00"> ว่าง <?php echo e($rm->NumberPeople - $rm->AtNumberPreple); ?> ที่ </p>
                        <?php endif; ?>

                    </td>
                    <td>
                        <?php if( $rm->Type  == 1): ?>
                            ห้องปรับอากาศ
                        <?php else: ?>
                            ห้องพัดลม
                        <?php endif; ?>
                        
                    </td>
                    <td><?php echo e($rm->Name_Thai); ?></td>
                    <td>
                        <center>
                        <form method="post" action="<?php echo e(route('rooms.destroy',$rm->RoomCode_ID)); ?>">
                            <?php echo csrf_field(); ?>

                            <a class="btn btn-warning width:40px" href="<?php echo e(route('rooms.edit',$rm->RoomCode_ID)); ?>" >แก้ไขข้อมูล</a>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger width:40%" type="submit">ลบข้อมูล </button>

                        </form>
                        </center>
                    </td>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

<?php else: ?>
<div class="alert alert-danger col-sm-10 my-2">
    <p style="text-align:center">ไม่มีข้อมูล หัวข้อปัญหา</p>
</div>
<?php endif; ?>

<?php echo e($room->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/rooms/create.blade.php ENDPATH**/ ?>