<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">My Profile</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <p><strong>id : </strong><?php echo Auth::user()->id; ?></p>
                    <p><strong>Name : </strong><?php echo Auth::user()->name; ?></p>
                    <p><strong>Email : </strong><?php echo Auth::user()->email; ?></p>
                    <center>
                    <?php if( Auth::user()->checkIsAdmin() ): ?>
                        <a href="admin/dormitory" class="btn btn-primary">Management</a>
                    <?php endif; ?>
                    

                    <?php if(  sizeof($userdetail ) == 1  ): ?>
                        
                        <a href="<?php echo e(route('UserDetail.edit',Auth::user()->id )); ?> " class="btn btn-warning">แก้ไขข้อมูลส่วนตัว</a>
                    <?php else: ?>
                        
                        <a href="<?php echo e(route('UserDetail.create')); ?> " class="btn btn-info">เพื่มข้อมูลส่วนตัว</a>
                    <?php endif; ?>
                        


                    <?php if(  sizeof($userdetail ) == 1  ): ?>
                        
                        <a href="/user/reservations/index" class="btn btn-success">จองห้อง</a>

                    <?php else: ?>
                        <a href="<?php echo e(Auth::user()->id); ?>" onclick="return confirm('คุณยังไม่ได้เพื่มข้อมูลส่วนตัว \nกรุณาเพื่มข้อมูลส่วนตัวก่อน ไม่งั้นจะจองห้องไม่ได้ค่ะ')" class="btn btn-danger">จองห้อง</a>
                    <?php endif; ?>


                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/home.blade.php ENDPATH**/ ?>