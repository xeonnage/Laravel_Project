
<?php $__env->startSection('body'); ?>
<?php $__currentLoopData = $roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rmty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="table-responsive">
    <p><h2>แก้ไข้ข้อมูล ห้องพัก</h2></p>
    <form action="<?php echo e(route('roomtype.update',$rmty->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="Description">ชื่อหอพัก <label style="color:red;"> * </label></label>
            <div >
                
                <select class="form-control" name="Dormitory_ID">

                    
                    <?php $__currentLoopData = $dormitory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dormitory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($dormitory->id == $rmty->Dormitory_ID): ?>
                        <option selected value = "<?php echo e($dormitory->id); ?>">
                            <?php echo e($dormitory->Name_Thai); ?> --สถานะปัจุบัน--
                        </option>
                    <?php else: ?>
                        <option value = "<?php echo e($dormitory->id); ?>">
                            <?php echo e($dormitory->Name_Thai); ?>

                        </option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="Description">ประเภทห้องพัก <label style="color:red;"> * </label></label>
            <div >
                <select class="form-control" name="Type">
                    <option value="<?php echo e($rmty->Type); ?>">
                        <label style="color:red "> สถานะปัจุบัน: </label>
                            <?php if( $rmty->Type  == 1): ?>
                                ห้องปรับอากาศ
                            <?php else: ?>
                                ห้องพัดลม
                            <?php endif; ?>
                        
                    </option>
                    <option value="1">ห้องปรับอากาศ</option>
                    <option value="2">ห้องพัดลม</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="Name_TH">จำนวนคนทั้งหมด/ห้อง <label style="color:red;"> * </label></label>
            <input type="text" class="form-control" name="NumberPeople" id="NumberPeople" value="<?php echo e($rmty->NumberPeople); ?>">
        </div>





        <button type="submit" name="submit" class="btn btn-warning">แก้ไขข้อมูล</button>
        <button class="btn btn-secondary" type="reset">ยกเลิก</button>




</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/roomtype/edit.blade.php ENDPATH**/ ?>