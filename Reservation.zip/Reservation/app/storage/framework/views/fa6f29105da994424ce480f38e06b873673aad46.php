<?php $__env->startSection('body'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">ประเภทห้องพัก
                
                <a  class="btn btn-success mr-2 "
                    style="position:absolute ; right:0 ; top:5px"
                    href="roomtype/create" >เพิ่มประเภทห้อพัก
                </a>
            </div>
                <?php echo csrf_field(); ?>

        <body  style="">

            <table class="table" border="0">
                <thead>
                    <th><center>#ID</center></th>
                    <th><center>ชื่อหอพัก</center></th>
                    <th><center>ประเภทหอพัก</center></th>
                    <th><center>ประเภทห้องพัก</center></th>
                    <th><center>จำนวนคน </center></th>
                    <th><center>การดำเนินการ</center></th>

                    
                </thead>
                <?php   $i=1;?>
                <?php $__currentLoopData = $roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rmty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <td><?php echo e($i++); ?> </td>
                    
                    
                    <td><?php echo e($rmty->Name_Thai); ?></td>
                    <td><?php echo e($rmty->Description); ?></td>
                    <td>
                        <?php if( $rmty->Type  == 1): ?>
                            ห้องปรับอากาศ
                        <?php else: ?>
                            ห้องพัดลม
                        <?php endif; ?>
                        
                    </td>
                    <td><center> <?php echo e($rmty->NumberPeople); ?> คน/ห้อง </center></td>


                    <td>
                        <center>
                        <form method="post" action="<?php echo e(route('roomtype.destroy',$rmty->roomTypeId)); ?>">
                            <?php echo csrf_field(); ?>

                            <a class="btn btn-warning width:40px" href="<?php echo e(route('roomtype.edit',$rmty->roomTypeId)); ?>" >แก้ไขข้อมูล</a>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger width:40%" type="submit">ลบข้อมูล </button>

                        </form>
                        </center>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($roomtype->links()); ?>

        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/roomtype/index.blade.php ENDPATH**/ ?>