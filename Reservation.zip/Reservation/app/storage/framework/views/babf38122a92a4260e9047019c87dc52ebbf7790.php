
<?php $__env->startSection('body'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <label style="font-size: 20px; font-weight: bold;" >ข้อมูลประเภทหอพัก </label>&nbsp;&nbsp;
                <a href="/admin/roomtype"> แสดงประเภทห้องพักทั้งหมด </a>
                <a  class="btn btn-success mr-2 "
                    style="position:absolute ; right:0 ; top:12px; text-align:right"
                    
                    href="/admin/roomtype/create" >เพิ่มประเภทหอพัก
                </a>
            </div>
                <?php echo csrf_field(); ?>

        <body  style="">

            <table class="table" border="0">
                <thead>
                    <tr>
                        <td>ชื่อหอพักภาษาอังกฤษ</td>
                        <td><?php echo e($dormitoryData[0]->Name_Eng); ?></td>
                    </tr>
                    <tr>
                        <td>ชื่อหอพักภาษาไทย</td>
                        <td><?php echo e($dormitoryData[0]->Name_Thai); ?></td>
                    </tr>
                    <tr>
                        <td>ประเภทหอพัก</td>
                        <td><?php echo e($dormitoryData[0]->Description); ?></td>
                    </tr>
                </thead>
                <thead>
                    <th><center>#ลำดับ</center></th>
                    <th><center>ประเภทห้องพัก</center></th>
                    <th><center>จำนวนคน</center></th>

                    <th><center>การดำเนินการ</center></th>

                    
                </thead>
                <?php   $i=1;?>

                <tbody>
                    <?php if(sizeof($dormitory) != 0): ?>
                        <?php $__currentLoopData = $dormitory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dorm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?> </td>
                                <td>
                                    <?php if( $dorm->Type == 1 ): ?>
                                        ห้องปรับอากาศ
                                    <?php else: ?>
                                        ห้องพัดลม
                                    <?php endif; ?>
                                    
                                </td>
                                <td><center><?php echo e($dorm->NumberPeople); ?> คน/ห้อง</center></td>
                                <td>
                                    <center>
                                    <form method="post" action="<?php echo e(route('dormitory.destroy',$dorm->id)); ?>">
                                        <?php echo csrf_field(); ?>

                                        <a class="btn btn-primary" href="<?php echo e(route('roomtype.show',$dorm->Dormitory_ID.":".$dorm->Type )); ?>" >แสดงข้อมูล</a>
                                        <a class="btn btn-warning" href="<?php echo e(route('dormitory.edit',$dorm->id)); ?>" >แก้ไขข้อมูล</a>

                                        <?php echo method_field('DELETE'); ?>
                                        

                                    </form>
                                    </center>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4"><h4 style="text-align:center"><label style="color: #ff5050"> --- ไม่มีข้อมูลประเภทหอพัก ---</label></h4></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/dormitory/show.blade.php ENDPATH**/ ?>