

<?php $__env->startSection('body'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">หอพักนิสิต
                
                <a  class="btn btn-success mr-2 "
                    style="position:absolute ; right:0 ; top:5px"
                    href="dormitory/create" >เพิ่มหอพัก
                </a>
            </div>
                <?php echo csrf_field(); ?>

        <body  style="">

            <table class="table" border="0">
                <thead>
                    <th><center>ลำดับ</center></th>
                    
                    <th><center>สถานะ</center></th>
                    <th><center>รหัสนิสิต</center></th>
                    <th><center>Firstname</center></th>
                    <th><center>Lastname</center></th>
                    <th><center>เพศ</center></th>
                    <th><center>การดำเนินการ</center></th>

                    
                </thead>
                <?php   $i=1;?>
                <?php $__currentLoopData = $userdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usdt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($usdt->Status); ?></td>
                    <td><?php echo e($usdt->Collegian_ID); ?></td>
                    <td><?php echo e($usdt->Firstname_Eng); ?></td>
                    <td><?php echo e($usdt->Lastname_Eng); ?></td>
                    <td><?php echo e($usdt->Gender); ?></td>
                    <td><?php echo e($usdt->Status); ?></td>

                    <td>
                        <center>
                        <a class="btn btn-primary" href="/user/UserDetail/show/<?php echo e($usdt->id); ?>" >แสดงข้อมูล</a>
                        
                        </center>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/userdetails/index.blade.php ENDPATH**/ ?>