
<?php $__env->startSection('body'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="table-responsive">
    <p><h2>เพื่มข้อมูล หอพักนิสิต</h2></p>
    <form action="<?php echo e(route('dormitory.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="Name_EN">ชื่อหอพักภาษาอังกฤษ <label style="color:red;"> * </label></label>
            <input type="text" class="form-control" name="Name_Eng" id="Name_Eng" placeholder="Tao-Thong Student Dormitory">
        </div>
        <div class="form-group">
            <label for="Name_TH">ชื่อหอพักภาษาไทย <label style="color:red;"> * </label></label>
            <input type="text" class="form-control" name="Name_Thai" id="Name_Thai" placeholder="หอพักนักศึกษา เทา-ทอง">
        </div>
        <div class="form-group">
            <label for="Description">ประเภทหอพัก <label style="color:red;"> * </label></label>
            <div >
                <select class="form-control" name="Description">
                    <option value="">โปรดเลือกประเภทหอพัก</option>
                    <option value="หอพักนิสิต ชาย">หอพักนิสิต ชาย</option>
                    <option value="หอพักนิสิต หญิง">หอพักนิสิต หญิง</option>
                </select>
            </div>
            
        </div>

        <button type="submit" name="submit" class="btn btn-success">เพื่มข้อมูล</button>
        <button class="btn btn-secondary" type="reset">ยกเลิก</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/dormitory/create.blade.php ENDPATH**/ ?>