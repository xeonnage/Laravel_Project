
<?php $__env->startSection('body'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="table-responsive">
    <p><h2>เพื่มข้อมูล ประเภทห้องพัก</h2></p>
    <form action="<?php echo e(route('roomtype.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        

        <div class="form-group">
            <label for="Description">ชื่อหอพัก <label style="color:red;"> * </label></label>
            <div >
                <select class="form-control" name="Dormitory_ID">
                    <option value="" ><label style="color:brown" >กรุณาเลือกหอพัก</label></option>
                    <?php $__currentLoopData = $dormitory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dormitory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value = "<?php echo e($dormitory->id); ?>">
                        <?php echo e($dormitory->Name_Thai); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="Description">ประเภทห้องพัก <label style="color:red;"> * </label></label>
            <div >
                <select class="form-control" name="Type">
                    <option value="">โปรดเลือกประเภทห้องพัก</option>
                    <option value="1">ห้องปรับอากาศ</option>
                    <option value="2">ห้องพัดลม</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="Name_TH">จำนวนคนทั้งหมด/ห้อง <label style="color:red;"> * </label></label>
            <input type="text" class="form-control" name="NumberPeople" id="NumberPeople" placeholder="จำนวนคน : 4 คน ">
        </div>



        <button type="submit" name="submit" class="btn btn-success">เพื่มข้อมูล</button>
        <button class="btn btn-secondary" type="reset">ยกเลิก</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/roomtype/create.blade.php ENDPATH**/ ?>