<?php $__env->startSection('body'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <label style="font-size: 20px; font-weight: bold;" >ข้อมูลประเภทหอพัก </label>&nbsp;&nbsp;
                <a href="/admin/roomtype"> แสดงประเภทห้องพักทั้งหมด </a>
                <a  class="btn btn-success mr-2 "
                    style="position:absolute ; right:0 ; top:12px; text-align:right"
                    

                    href="<?php echo e(route('rooms.create',$dormitory[0]->id.":".$type)); ?>" >เพิ่มหอพัก
                </a>
            </div>
                <?php echo csrf_field(); ?>

        <body  style="">

            <table class="table" border="0">
                <thead>
                    <tr>
                        <td>ชื่อหอพักภาษาอังกฤษ</td>
                        <td><?php echo e($dormitory[0]->Name_Eng); ?></td>
                    </tr>
                    <tr>
                        <td>ชื่อหอพักภาษาไทย</td>
                        <td><?php echo e($dormitory[0]->Name_Thai); ?></td>
                    </tr>
                    <tr>
                        <td>ประเภทหอพัก</td>
                        <td><?php echo e($dormitory[0]->Description); ?></td>
                    </tr>
                    <tr>
                        <td>ประเภทหอห้องพัก</td>
                        <td>
                            <?php if( $type == 1 ): ?>
                                ห้องปรับอากาศ
                            <?php else: ?>
                                ห้องพัดลม
                            <?php endif; ?>
                        </td>
                    </tr>
                </thead>
                <thead>
                    <th><center>#ลำดับ</center></th>
                    <th><center>เลขห้อง</center></th>
                    <th><center>ชั้น</center></th>
                    <th><center>จำนวนคน</center></th>
                    <th><center>สถานะ</center></th>
                    <th><center>การดำเนินการ</center></th>

                    
                </thead>
                <?php   $i=1;?>
                <?php if( sizeof($roomtype) != 0): ?>
                <?php $__currentLoopData = $roomtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rmty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                    <tr>
                        <td><?php echo e($i++); ?> </td>
                        
                        
                        <td><?php echo e($rmty->RoomCode_ID); ?></td>
                        <td><?php echo e($rmty->Floor); ?></td>
                        <td><center> <?php echo e($rmty->AtNumberPreple); ?> คน/ห้อง </center></td>
                        <td> <?php echo e($rmty->StatusRoom); ?> </td>


                        <td>
                            <center>
                            <form method="post" action="<?php echo e(route('roomtype.destroy',$rmty->RoomCode_ID)); ?>">
                                <?php echo csrf_field(); ?>

                                <a class="btn btn-warning width:40px" href="<?php echo e(route('roomtype.edit',$rmty->RoomCode_ID)); ?>" >แก้ไขข้อมูล</a>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger width:40%" type="submit">ลบข้อมูล </button>

                            </form>
                            </center>
                        </td>
                    </tr>
                    </tbody>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <tr>
                    <td colspan="6"><h4 style="text-align:center"><label style="color: #ff5050"> --- ไม่มีข้อมูลประเภทหอพัก ---</label></h4></td>
                </tr>
                <?php endif; ?>
            </table>

        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/admin/roomtype/show.blade.php ENDPATH**/ ?>