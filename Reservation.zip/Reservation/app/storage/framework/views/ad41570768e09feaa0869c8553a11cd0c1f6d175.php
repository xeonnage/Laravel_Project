<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">ห้องพักทั้งหมด</div>
                <?php echo csrf_field(); ?>

        <body  style="">

            <table class="table" border="0">
                <thead>
                    <th><center>#ลำดับ</center></th>
                    <th><center>เลขหอพัก</center></th>
                    <th><center>ชั้น</center></th>
                    <th><center>จำนวนคน</center></th>
                    <th><center>สถานะ</center></th>
                    <th><center>ประเภทห้องพัก </center></th>
                    <th><center>ชื่อหอพัก </center></th>
                    <th><center>การดำเนินการ</center></th>

                    
                </thead>
                <?php   $i=1;?>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($rm->RoomCode_ID); ?></td>
                    <td><?php echo e($rm->Floor); ?></td>
                    <td><?php echo e($rm->NumberPeople); ?> คน/ห้อง</td>
                    <td>
                        <?php if( $rm->NumberPeople == $rm->AtNumberPreple ): ?>
                           <p style="color: #ff1a1a"> ห้องเต็ม</p>
                        <?php else: ?>
                           <p style="color: #00cc00"> ว่าง <?php echo e($rm->NumberPeople - $rm->AtNumberPreple); ?> ที่ </p>
                        <?php endif; ?>

                    </td>
                    <td>
                        <?php if( $rm->Type  == 1): ?>
                            ห้องปรับอากาศ
                        <?php else: ?>
                            ห้องพัดลม
                        <?php endif; ?>
                        
                    </td>
                    <td><?php echo e($rm->Name_Thai); ?></td>
                    <td>
                        
                        <a class="btn btn-success width:40px" href="/user/reservations/create/<?php echo e($reservations[0]->id); ?>" >จองห้อง</a>
                    </td>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/user/reservations/index.blade.php ENDPATH**/ ?>