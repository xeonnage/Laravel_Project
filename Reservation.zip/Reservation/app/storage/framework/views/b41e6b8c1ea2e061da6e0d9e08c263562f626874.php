<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="table-responsive">
            <?php echo e(Auth::user()->email); ?>


            <p><h2>จองหอห้อง</h2></p>
            <form action="<?php echo e(route('dormitory.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>



                <div class="form-inline">
                    <div class="form-group col-xs-10 col-sm-10 col-md-10 my-2">
                    <strong for="Description" class="col-sm-2">หอพัก <font style="color:red;"> * </font></strong>
                    <nav class = "col-sm-8">
                        <select class="form-control" name="RoomCode_ID">
                            <option value="" ><label style="color:brown" >กรุณาเลือกหอพัก</label></option>
                            <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value = "<?php echo e($room->id); ?>">
                                
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <?php echo e($room->RoomCode_ID); ?>

                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                <?php echo e($room->Name_Thai); ?>

                                    &nbsp;&nbsp;&nbsp;&nbsp;

                                <?php if( $room->Roomtype_ID == 1 ): ?>
                                    ห้องปรับอากาศ
                                <?php else: ?>
                                    ห้องพัดลม
                                <?php endif; ?>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    เหลือที่ว่าง
                                <?php echo e($room->AtNumberPreple); ?>

                                    ที่




                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </nav>
                    </div>

                    <div class="form-group col-xs-10 col-sm-10 col-md-10 my-2">
                    <strong for="Description" class="col-sm-2">ภาคเรียน <font style="color:red;"> * </font></strong>
                    <nav class = "col-sm-8">
                        <select class="form-control" name="Type">
                            <option value="">โปรดเลือกภาคเรียน</option>
                            <option value="ภาคเรียนปลาย">ภาคเรียนปลาย</option>
                            <option value="ภาคเรียนปลาย">ภาคเรียนปลาย</option>
                            <option value="ภาคเรียนฤดูร้อน">ภาคเรียนฤดูร้อน</option>
                        </select>
                    </nav>
                    </div>
                </div>



                <button type="submit" name="submit" class="btn btn-success">เพื่มข้อมูล</button>
                <button class="btn btn-secondary" type="reset">ยกเลิก</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/user/reservations/create.blade.php ENDPATH**/ ?>